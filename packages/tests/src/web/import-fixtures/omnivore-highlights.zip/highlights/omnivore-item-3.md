# Highlights of Omnivore article 4

> First passage of article 4, worth keeping.



> A second passage
> that runs over two lines.