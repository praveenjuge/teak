# Highlights of Omnivore article 1

> First passage of article 1, worth keeping.

My note on article 1.

> A second passage
> that runs over two lines.