# Highlights of Omnivore article 14

> First passage of article 14, worth keeping.



> A second passage
> that runs over two lines.