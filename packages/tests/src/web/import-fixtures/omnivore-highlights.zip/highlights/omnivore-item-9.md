# Highlights of Omnivore article 10

> First passage of article 10, worth keeping.



> A second passage
> that runs over two lines.