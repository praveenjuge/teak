# Highlights of Omnivore article 19

> First passage of article 19, worth keeping.

My note on article 19.

> A second passage
> that runs over two lines.