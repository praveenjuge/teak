# Highlights of Omnivore article 11

> First passage of article 11, worth keeping.

My note on article 11.

> A second passage
> that runs over two lines.