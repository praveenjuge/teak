# Highlights of Omnivore article 8

> First passage of article 8, worth keeping.



> A second passage
> that runs over two lines.