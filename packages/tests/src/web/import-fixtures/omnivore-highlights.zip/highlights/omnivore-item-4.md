# Highlights of Omnivore article 5

> First passage of article 5, worth keeping.

My note on article 5.

> A second passage
> that runs over two lines.