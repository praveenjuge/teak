# Highlights of Omnivore article 16

> First passage of article 16, worth keeping.



> A second passage
> that runs over two lines.