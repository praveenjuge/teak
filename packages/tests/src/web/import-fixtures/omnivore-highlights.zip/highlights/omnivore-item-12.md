# Highlights of Omnivore article 13

> First passage of article 13, worth keeping.

My note on article 13.

> A second passage
> that runs over two lines.