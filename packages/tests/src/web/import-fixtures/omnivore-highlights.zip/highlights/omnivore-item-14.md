# Highlights of Omnivore article 15

> First passage of article 15, worth keeping.

My note on article 15.

> A second passage
> that runs over two lines.