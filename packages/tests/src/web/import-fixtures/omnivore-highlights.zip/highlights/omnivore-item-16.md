# Highlights of Omnivore article 17

> First passage of article 17, worth keeping.

My note on article 17.

> A second passage
> that runs over two lines.