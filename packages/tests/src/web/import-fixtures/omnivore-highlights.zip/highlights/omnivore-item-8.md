# Highlights of Omnivore article 9

> First passage of article 9, worth keeping.

My note on article 9.

> A second passage
> that runs over two lines.