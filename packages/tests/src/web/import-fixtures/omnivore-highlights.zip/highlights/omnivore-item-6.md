# Highlights of Omnivore article 7

> First passage of article 7, worth keeping.

My note on article 7.

> A second passage
> that runs over two lines.