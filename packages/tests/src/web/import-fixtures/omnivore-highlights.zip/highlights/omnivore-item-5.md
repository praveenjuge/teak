# Highlights of Omnivore article 6

> First passage of article 6, worth keeping.



> A second passage
> that runs over two lines.