# Highlights of Omnivore article 3

> First passage of article 3, worth keeping.

My note on article 3.

> A second passage
> that runs over two lines.