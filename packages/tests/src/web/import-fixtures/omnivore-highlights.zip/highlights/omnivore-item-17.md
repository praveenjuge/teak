# Highlights of Omnivore article 18

> First passage of article 18, worth keeping.



> A second passage
> that runs over two lines.