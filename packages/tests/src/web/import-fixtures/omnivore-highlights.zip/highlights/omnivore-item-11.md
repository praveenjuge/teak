# Highlights of Omnivore article 12

> First passage of article 12, worth keeping.



> A second passage
> that runs over two lines.