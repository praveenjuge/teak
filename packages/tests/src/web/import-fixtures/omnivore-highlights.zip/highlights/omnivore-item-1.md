# Highlights of Omnivore article 2

> First passage of article 2, worth keeping.



> A second passage
> that runs over two lines.